export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDrYYwn8joas5nm8jJnBnZDqb9MsV-g2qY",
    authDomain: "angularpwa-21e2f.firebaseapp.com",
    databaseURL: "https://angularpwa-21e2f.firebaseio.com",
    projectId: "angularpwa-21e2f",
    storageBucket: "angularpwa-21e2f.appspot.com",
    messagingSenderId: "374270193194",
    appId: "1:374270193194:web:60b0312a6289aaefa0dd53",
    measurementId: "G-9DK36E5GQ6"
  }
};
